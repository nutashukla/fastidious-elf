import Page from "./Page";



function App() {
  return (
    <div className="App">
      <Page/>
    </div>
  );
}

export default App;
